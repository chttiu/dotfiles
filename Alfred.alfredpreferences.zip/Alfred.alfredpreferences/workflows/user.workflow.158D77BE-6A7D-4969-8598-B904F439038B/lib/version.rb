# frozen_string_literal: true

class App
  VERSION = '3.1.3'
end
